@extends('front.layout.main')
@section('content')
	@include('front.layout.about')
@endsection