@extends('front.layout.main')
@section('content')
	@include('front.layout.contact')
@endsection