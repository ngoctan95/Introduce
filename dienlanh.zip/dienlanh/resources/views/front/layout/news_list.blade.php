
                        <div class="block-content">
                            <div class="menu-recent view">
                                <dt class="block-title"><strong><span>Tin tức</span></strong></dt>
                                <dd>
                                    <ol>
                                        <li><a href="{{url('/news/detail/1')}}">Tin tức 1</a></li>
                                        <li><a href="{{url('/news/detail/2')}}">Tin tức 2</a></li>
                                        <li><a href="{{url('/news/detail/3')}}">Tin tức 3</a></li>
                                        <li><a href="{{url('/news/detail/4')}}">Tin tức 4</a></li>
                                        <li><a href="{{url('/news/detail/5')}}">Tin tức 5</a></li>
                                    </ol>
                                </dd>
                            </div>
                        </div>