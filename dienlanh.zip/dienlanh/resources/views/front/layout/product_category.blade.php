<div class="col-md-3 col-sm-12 sidebar">
    <h3 class="section-title">Danh mục sản phẩm</h3>
    <div class="sidebar-filter">
        <div class="manufacture">
            <ul>
                <li><a href="#">Đá granite <span class="item-count">(22)</span></a></li>
                <li><a href="#">Đá marble <span class="item-count">(45)</span></a></li>
                <li><a class="active" href="#">Hoa văn <span class="item-count">(29)</span></a></li>
                <li><a href="#">Bột đá <span class="item-count">(41)</span></a></li>
                <li><a href="#">Sản phẩm tiêu biểu <span class="item-count">(58)</span></a></li>
            </ul>
        </div>
        
    </div>
    
</div>