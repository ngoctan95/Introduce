
<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-lg-12">
				<div class="wow shake" data-wow-delay="0.4s">
				<div class="page-scroll marginbot-30">
					<a href="#intro" id="totop" class="btn btn-circle">
						<i class="fa fa-angle-double-up animated"></i>
					</a>
				</div>
				</div>
				<p>&copy;Copyright 2014 - Hung Ocean Co.,LTD. Designed by <a href="mailto:nthung0209@gmail.com">HERO</a></p>
                <!-- 
                    All links in the footer should remain intact. 
                    Licenseing information is available at: http://bootstraptaste.com/license/
                    You can buy this theme without footer links online at: http://bootstraptaste.com/buy/?theme=Squadfree
                -->
			</div>
		</div>	
	</div>
</footer>