# SB Admin v2.0 rewritten in Laravel

This project is a part of the famous Free Admin Bootstrap Theme SB Admin v2.0 to Laravel Theme.

Find out more [Free Laravel Themes at StartLaravel.com](http://www.startlaravel.com/)..

## Installation

1. Clone this project or Download that ZIP file
2. Make sure you have bower, gulp and npm installed globally
3. On the command prompt run the following commands
- cd `project-directory`
- Set permission 777 for storage
- `composer install`
- `npm install`
- `bower install`
- `gulp watch`
- `php artisan cache:clear`

### Automation tools

- [Gulp](http://gulpjs.com/)
